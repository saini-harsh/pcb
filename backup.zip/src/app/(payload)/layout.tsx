import config from '@payload-config'
import { RootLayout, metadata } from '@payloadcms/next/layouts'
import React from 'react'
import { importMap } from './admin/importMap'
import { handleServerFunction } from './actions'
import '@payloadcms/next/css'

export const dynamic = 'force-dynamic'
export { metadata }

type Args = {
  children: React.ReactNode
}

const Layout = async ({ children }: Args) => (
  <RootLayout
    config={config}
    importMap={importMap}
    serverFunction={handleServerFunction as any}
  >
    {children}
  </RootLayout>
)

export default Layout
