import config from '@payload-config'
import { RootPage, generatePageMetadata } from '@payloadcms/next/views'
import { Metadata } from 'next'
import { ImportMap } from 'payload'

import { importMap } from '../importMap'

type Args = {
  params: Promise<{
    segments: string[]
  }>
  searchParams: Promise<{
    [key: string]: string | string[]
  }>
}

export const generateMetadata = ({ params, searchParams }: Args): Promise<Metadata> =>
  generatePageMetadata({ config, params, searchParams })

const Page = async ({ params, searchParams }: Args) => {
  return RootPage({ 
    config, 
    importMap,
    params, 
    searchParams 
  })
}

export default Page
